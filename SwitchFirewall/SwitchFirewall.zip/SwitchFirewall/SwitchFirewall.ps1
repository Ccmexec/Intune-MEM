﻿# Place additional checks here that the device connected to the correct network.
Get-NetConnectionProfile -Name "demiranda.nu" | Set-NetConnectionProfile -NetworkCategory Private