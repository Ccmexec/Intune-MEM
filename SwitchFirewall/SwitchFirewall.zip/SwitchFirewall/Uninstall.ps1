<#
    Name: Uninstall.ps1
    Version: 1.0
    Author: Jörgen Nilsson
    Date: 2022-10-02
#>

[string]$RegKeyName = "SwitchFirewall"
[string]$FullRegKeyName = "HKLM:\SOFTWARE\ccmexec\"
[string]$InstallPath = "$env:ProgramFiles\SwitchFirewall"

# Remove registry key
Remove-Item -Path $FullRegKeyName -Recurse -force

# Remove Files
Remove-Item -Path $InstallPath -Recurse -force

# Delete ScheduelTask
Unregister-ScheduledTask -TaskName "SwitchFirewall" -Confirm:$false
