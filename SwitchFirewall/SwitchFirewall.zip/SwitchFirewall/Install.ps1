<#
    Name: Install.ps1 
    Version: 1.0
    Author: J�rgen Nilsson
    Date: 2020-11-15
#>

[string]$RegKeyName = "SwitchFirewall"
[string]$FullRegKeyName = "HKLM:\SOFTWARE\Ccmexec\"
[string]$InstallPath = "$env:ProgramFiles\SwitchFirewall"

# Create registry value if it doesn't exist
If (!(Test-Path $FullRegKeyName)) {
    New-Item -Path $FullRegKeyName -type Directory -force 
    New-itemproperty $FullRegKeyName -Name "SwitchFirewall" -Value "1" -Force
    }
If (!(Test-Path $InstallPath)) {
    New-Item -Path $InstallPath -type Directory -force 
    }

Copy-Item -Path "$PSScriptRoot\SwitchFirewall.ps1" -Destination $InstallPath -Recurse -Force

# Creates ScheduleTask
Register-ScheduledTask -Xml (get-content $PSScriptRoot\SwitchFirewall.xml | out-string) -TaskName "SwitchFirewall"

