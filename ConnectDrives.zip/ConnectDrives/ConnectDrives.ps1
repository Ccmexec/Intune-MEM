﻿If (!(Test-Path G:)) {
   New-PSDrive G -PSProvider FileSystem -Persist -Root "\\d00008\share"
}

If (!(Test-Path M:)) {
   New-PSDrive M -PSProvider FileSystem -Persist -Root "\\d00008\sources"
}
