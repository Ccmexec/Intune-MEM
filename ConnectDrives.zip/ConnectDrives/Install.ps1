<#
    Name: Install.ps1 
    Version: 1.0
    Author: J�rgen Nilsson
    Date: 2020-11-15
#>[string]$RegKeyName = "ConnectDrives"[string]$FullRegKeyName = "HKLM:\SOFTWARE\ccmexec\" + $regkeyname [string]$InstallPath = "$env:ProgramFiles\ConnectDrives"# Create registry value if it doesn't existIf (!(Test-Path $FullRegKeyName)) {    New-Item -Path $FullRegKeyName -type Directory -force     New-itemproperty $FullRegKeyName -Name "Connectdrives" -Value "1" -Type STRING -Force    }If (!(Test-Path $InstallPath)) {    New-Item -Path $InstallPath -type Directory -force     }Copy-Item -Path "$PSScriptRoot\ConnectDrives.ps1" -Destination $InstallPath -Recurse -ForceCopy-Item -Path "$PSScriptRoot\psrun.exe" -Destination $InstallPath -Recurse -Force# Creates ScheduleTask
Register-ScheduledTask -Xml (get-content $PSScriptRoot\ConnectDrives.xml | out-string) -TaskName "ConnectDrives"